# Next.js + Tailwind CSS Project

`npm install`

`npm run dev`
